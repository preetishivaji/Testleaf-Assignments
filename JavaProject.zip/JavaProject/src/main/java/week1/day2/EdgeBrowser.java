package week1.day2;

public class EdgeBrowser {

	public static void main(String[] args) {
		Browser bro = new Browser();
		bro.launchBrowser("Edge");
		bro.loadUrl();

	}

}

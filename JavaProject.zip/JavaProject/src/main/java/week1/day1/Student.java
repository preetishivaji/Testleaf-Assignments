package week1.day1;

public class Student {
	
	String studentName = "Preeti";
	int rollNo = 4;
	String collegeName = "ABC";
	int markScored = 1012;
	int cgpa = 8;
	

	public static void main(String[] args) {
		

	}

}


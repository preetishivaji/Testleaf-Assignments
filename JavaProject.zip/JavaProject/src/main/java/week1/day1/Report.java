package week1.day1;

public class Report {

	public static void main(String[] args) {
		
		Student st = new Student();
		System.out.println(st.studentName);
		System.out.println(st.rollNo);
		System.out.println(st.collegeName);
		System.out.println(st.markScored);
		System.out.println(st.cgpa);
		

	}

}

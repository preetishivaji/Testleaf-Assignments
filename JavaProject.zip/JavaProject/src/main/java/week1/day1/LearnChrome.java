package week1.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnChrome {

	public static void main(String[] args) {
		
		ChromeDriver driver=new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.close();

	}

}

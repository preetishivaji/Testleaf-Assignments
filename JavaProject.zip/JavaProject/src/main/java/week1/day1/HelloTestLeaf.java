package week1.day1;

public class HelloTestLeaf {
	public static void main(String[] args) {
		System.out.println("Welcome to Testleaf");
	}

}

package week3.day1;

public class TextField extends WebElement {
	
	public void getText() {
		
	}

	public static void main(String[] args) {
		

	}

}

package week3.day1;

public class Button extends WebElement{
	
	public void submit() {
		
	}

	public static void main(String[] args) {
		

	}

}

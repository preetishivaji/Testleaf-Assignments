package week3.day1;

public class WebElement {
	
	public void click() {
		
	}
	
	public void setText(String text) {
		
	}

	public static void main(String[] args) {
		

	}

}

package week3.day1;

public class BasePage {
	
	public void findElement() {	
		System.out.println("findelement");
	}
	
	public void clickElement() { 
		System.out.println("clickelement");
	}
	
	public void enterText() { 
		System.out.println("entertext");
	}
	
	public void performCommonTasks() { 
		System.out.println("performcommontasks_parent");
	}

	public static void main(String[] args) {
		

	}

}

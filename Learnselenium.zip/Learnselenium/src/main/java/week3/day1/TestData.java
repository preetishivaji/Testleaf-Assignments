package week3.day1;

public class TestData {
	
	public void enterCredentials() {
		System.out.println("enterCredentials");
	}
	
	public void navigateToHomePage() {
		System.out.println("navigateToHomePage");
	}

	
}

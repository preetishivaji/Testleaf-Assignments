package week3.day1;

public class CheckBoxButton extends Button{
	
	public void clickCheckButton() {
		
	}

	public static void main(String[] args) {
		

	}

}

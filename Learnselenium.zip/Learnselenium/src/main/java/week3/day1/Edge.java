package week3.day1;

public class Edge extends Chrome {

	public static void main(String[] args) {
		Edge ed = new Edge();
		ed.closeBrowser();
		ed.clearCache();

	}

}

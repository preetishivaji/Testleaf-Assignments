package week3.day1;

public class Browser {
	
	public void openURL()
	{
		System.out.println("openURL");
	}
	
	public void closeBrowser()
	{
		System.out.println("closeBrowser");
	}
	
	public void navigateBack()
	{
		System.out.println("navigateBack");
	}
	
	
	public static void main(String[] args) {
		String browserName = "Chrome";
		int browserVersion = 12;
		
		
		

	}

}

package week3.day1;

public class Elements extends Button {

	public static void main(String[] args) {
		Elements e=new Elements();
		e.submit();
		e.click();
		e.setText("Test");

	}

}

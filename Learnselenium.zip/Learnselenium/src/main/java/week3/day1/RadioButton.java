package week3.day1;

public class RadioButton extends Button {
	
	public void selectRadioButton() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

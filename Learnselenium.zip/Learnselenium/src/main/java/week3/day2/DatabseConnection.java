package week3.day2;

public interface DatabseConnection {
	
	public void connect();
	public void disconnect();
	public void executeUpdate();

}

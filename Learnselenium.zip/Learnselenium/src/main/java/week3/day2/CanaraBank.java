package week3.day2;

public abstract class CanaraBank implements Payments {
	
	public void recordPaymentDetails() {
		System.out.println("Payment specifics");
	}

	public abstract void cashOnDelivery();
	
	public abstract void upiPayments();

	public abstract void cardPayments();

	public abstract void internetBanking();

}

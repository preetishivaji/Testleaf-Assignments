package week3.day2;

public class Amazon extends CanaraBank{


	@Override
	public void cashOnDelivery() {
		System.out.println("COD");
		
	}

	@Override
	public void upiPayments() {
		System.out.println("UPI");
		
	}

	@Override
	public void cardPayments() {
		System.out.println("cards");
		
	}

	@Override
	public void internetBanking() {
		System.out.println("Internet Banking");
		
	}
	
	public static void main(String[] args) {
		Amazon am = new Amazon();
		am.cashOnDelivery();
		am.upiPayments();
		am.cardPayments();
		am.internetBanking();
		am.recordPaymentDetails();
				
	}
		
}


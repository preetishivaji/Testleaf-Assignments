package week4.day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWebTable {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://erail.in/");
		driver.findElement(By.id("txtStationFrom")).clear();
		driver.findElement(By.id("txtStationFrom")).sendKeys("MAS"+Keys.ENTER);
		driver.findElement(By.id("txtStationTo")).clear();
		driver.findElement(By.id("txtStationTo")).sendKeys("MDU"+Keys.ENTER);
		
		
		WebElement table= driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']"));
			
			List<WebElement> row = table.findElements(By.tagName("tr"));
			System.out.println(row.size());
				
			List<WebElement> col = row.get(1).findElements(By.tagName("td"));
			System.out.println(col.size());

			 
			System.out.println("One Column Data");
			for (int i = 2; i < row.size(); i++) 
			{
				WebElement onecolData = driver.findElement(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']/tbody/tr[" + i + "]/td[2]"));
				System.out.println(onecolData.getText());
			}
		

	}

}

package week4.day1;

import java.util.*;


import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LearnWindowHandle {

	public static void main(String[] args) {
		
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://www.amazon.in/");
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("phone");
		driver.findElement(By.id("nav-search-submit-button")).click();
		driver.findElement(By.xpath("//span[contains(@class,'a-size-medium a-color-base')]")).click();
		
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> winHan = new ArrayList <String>(windowHandles);
		
		driver.switchTo().window(winHan.get(1));
		System.out.println("Child tab: "+driver.getTitle());
		
		driver.switchTo().window(winHan.get(0));
		System.out.println("Parent tab: "+driver.getTitle());
		driver.close();
		

	}

}

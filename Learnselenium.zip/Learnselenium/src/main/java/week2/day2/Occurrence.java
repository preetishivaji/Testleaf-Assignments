package week2.day2;

public class Occurrence {

	public static void main(String[] args) {
		String name = "Testleaf";
		int count = 0;
		char[] charArray = name.toCharArray();
		for (int i=0;i<=charArray.length - 1;i++)
		{
			if (charArray[i]=='e')
			{
				count = count+1;
			}
		}
System.out.println(count);
	}

}

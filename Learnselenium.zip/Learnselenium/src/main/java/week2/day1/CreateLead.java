package week2.day1;



import java.io.IOException;

import org.openqa.selenium.By;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateLead extends BaseClass{

	@Test(dataProvider = "sendData")
	public void createLeadtest(String cname, String fname, String lname, String phno) {	
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phno);
		driver.findElement(By.name("submitButton")).click();
		
	}
	
	// data supplier
		@DataProvider // (name="supplyData")
		public String[][] sendData() throws IOException {
			ReadExecel exceldata=new ReadExecel();
			String[][] data = exceldata.readData();
			return data;
	
	
	
	
	
	/*public String[][] sendData() {
		String[][] data = new String [2][4];
		data[0][0]="TL";
		data[0][1]="abc";
		data[0][2]="d";
		data[0][3]="98";
		
		data[1][0]="ABC";
		data[1][1]="Preeti";
		data[1][2]="S";
		data[1][3]="97";
		
		return data;*/
		
	}
}

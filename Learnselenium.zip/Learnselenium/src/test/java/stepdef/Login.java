package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login extends BaseClass{
	
	
//	@Given ("Launch the browser")
//	public void launchBrowser ()
//	{
//		driver = new ChromeDriver();
//	}
//
//	@Given ("Load the url")
//	public void loadUrl()
//	{
//		driver.get("http://leaftaps.com/opentaps/");
//	}
	
	@Given("Enter the username as {string}")
	public void enterUsername(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
	}

	@Given("Enter the password as {string}")
	public void enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
	}

	@When("Click on Login button")
	public void clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Welcome page is displayed")
	public void VerifyWelcomePage() {
		System.out.println(driver.getTitle());
	}

	@But("Error message is displayed")
	public void error_message_is_displayed() {
		String errorMsg = driver
				.findElement(By.xpath("//p[text()='following error occurred during login: User not found.']"))
				.getText();
		System.out.println(errorMsg);
	}
	
}

